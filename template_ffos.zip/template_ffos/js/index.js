var routerHandler = {
	routes: {},
	navigate: false,
	bindEvents: function(){
		$(window).on('hashchange', function() {
  			routerHandler.checkRoute();
		});
	},
	addRoute: function (route, page){
		var i=0;
		for(i=0;i<route.length;i++){
			routerHandler.routes[route[i]] = page;	
		}
	},
	checkRoute: function() {
		if (this.routes.hasOwnProperty(location.hash) && routerHandler.navigate==false){
			routerHandler.navigate=true;
			$.ajax({
				type: "GET",
				url: this.routes[location.hash],
				data: {},
				dataType: "text"
			}).done(function(data){
				$('#scroller').html(data);
				//console.log(data);
				routerHandler.navigate=false;
			}).error(function( event, jqxhr, settings, thrownError ){
				alert('Error: ' + thrownError);
				routerHandler.navigate=false;
			});
		}
	}

}
var app = {
	initialize: function () {
		
		// primer código.
		routerHandler.addRoute(['','#','#main'],'content/mainpage.html');
		routerHandler.addRoute(['#about'],'content/aboutpage.html');
		// eventos
		routerHandler.bindEvents();
		app.bindEvents();
		routerHandler.checkRoute();
	},
	bindEvents: function () {
        $("#navbar li a").click(function (event) {
            $("#nav-collapse").removeClass("in").addClass("collapse");
        });
	}
}

window.onload= app.initialize;
